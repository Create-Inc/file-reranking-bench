import { useState, useEffect } from "react";

export default function ExplorePage() {
  const [searchInput, setSearchInput] = useState("");
  const [selectedPlace, setSelectedPlace] = useState(null);
  const [suggestions, setSuggestions] = useState([]);
  const [nearbyPlaces, setNearbyPlaces] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [heroImage, setHeroImage] = useState(null);

  useEffect(() => {
    async function fetchHeroImage() {
      try {
        const response = await fetch("/api/pexels-random-image-generator", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            query: "scenic hiking trail overlook nature",
            targetWidth: 1920,
            targetHeight: 1080,
            random: true,
          }),
        });

        if (!response.ok) {
          throw new Error("Failed to fetch hero image");
        }

        const data = await response.json();
        setHeroImage(data);
      } catch (err) {
        console.error("Error fetching hero image:", err);
        setError("Failed to load hero image");
      }
    }

    fetchHeroImage();
  }, []);

  useEffect(() => {
    const fetchSuggestions = async () => {
      if (!searchInput) {
        setSuggestions([]);
        return;
      }

      try {
        const response = await fetch(
          `/integrations/google-place-autocomplete/autocomplete/json?input=${encodeURIComponent(
            searchInput
          )}&radius=50000`
        );

        if (!response.ok) {
          throw new Error("Failed to fetch suggestions");
        }

        const data = await response.json();
        setSuggestions(data.predictions || []);
      } catch (err) {
        console.error("Error fetching suggestions:", err);
        setError("Failed to load location suggestions");
      }
    };

    const timeoutId = setTimeout(fetchSuggestions, 300);
    return () => clearTimeout(timeoutId);
  }, [searchInput]);

  const searchNearbyPlaces = async (placeDescription) => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(
        `/integrations/local-business-data/search?query=hiking trails, parks, natural landmarks near ${encodeURIComponent(
          placeDescription
        )}&limit=10`
      );

      if (!response.ok) {
        throw new Error("Failed to fetch nearby places");
      }

      const data = await response.json();
      setNearbyPlaces(data.data || []);
      setSelectedPlace(placeDescription);
      setSuggestions([]);
    } catch (err) {
      console.error("Error fetching nearby places:", err);
      setError("Failed to load nearby places");
    } finally {
      setLoading(false);
    }
  };

  const handleSuggestionClick = (suggestion) => {
    setSearchInput(suggestion.description);
    searchNearbyPlaces(suggestion.description);
  };

  return (
    <div className="min-h-screen bg-stone-100">
      {/* Hero Section */}
      <div className="relative h-[50vh]">
        {heroImage ? (
          <img
            src={heroImage.url}
            alt="Scenic hiking trail"
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full bg-stone-200" />
        )}
        <div className="absolute inset-0 bg-black bg-opacity-40" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white px-4">
          <h1
            className="text-4xl md:text-6xl font-bold text-center mb-6"
            style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.5)" }}
          >
            Explore Nearby Trails
          </h1>
          <p
            className="text-xl md:text-2xl text-center mb-8 max-w-2xl"
            style={{ textShadow: "1px 1px 2px rgba(0,0,0,0.5)" }}
          >
            Discover hidden gems and popular hiking spots in your area
          </p>
          <div className="w-full max-w-2xl relative">
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Enter your location..."
              className="w-full px-6 py-4 rounded-full text-black text-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-lg"
            />
            {suggestions.length > 0 && (
              <div className="absolute w-full mt-2 bg-white rounded-lg shadow-xl z-10 max-h-96 overflow-y-auto">
                {suggestions.map((suggestion) => (
                  <button
                    key={suggestion.place_id}
                    onClick={() => handleSuggestionClick(suggestion)}
                    className="w-full text-left px-6 py-3 hover:bg-emerald-50 text-stone-800 transition duration-200"
                  >
                    {suggestion.description}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Results Section */}
      <div className="max-w-6xl mx-auto py-12 px-4">
        {loading && (
          <div className="text-center text-xl text-stone-600">
            Searching for nearby places...
          </div>
        )}

        {error && (
          <div className="text-center text-xl text-red-600 mb-8">{error}</div>
        )}

        {selectedPlace && !loading && (
          <h2 className="text-3xl font-bold text-emerald-900 mb-8">
            Hiking Spots near {selectedPlace}
          </h2>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {nearbyPlaces.map((place) => (
            <div
              key={place.business_id}
              className="bg-white rounded-lg shadow-lg overflow-hidden transform hover:scale-105 transition duration-300"
            >
              {place.photos_sample && place.photos_sample[0] && (
                <img
                  src={place.photos_sample[0].photo_url}
                  alt={place.name}
                  className="w-full h-48 object-cover"
                />
              )}
              <div className="p-6">
                <h3 className="text-xl font-semibold text-emerald-900 mb-2">
                  {place.name}
                </h3>
                <div className="flex items-center mb-2">
                  <div className="flex text-amber-500">
                    {[...Array(5)].map((_, i) => (
                      <svg
                        key={i}
                        className={`w-5 h-5 ${
                          i < Math.round(place.rating)
                            ? "text-amber-500"
                            : "text-stone-300"
                        }`}
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>
                  <span className="ml-2 text-stone-600">
                    ({place.review_count} reviews)
                  </span>
                </div>
                <p className="text-stone-600 mb-4">{place.full_address}</p>
                {place.business_status === "OPEN" && (
                  <span className="inline-block bg-emerald-100 text-emerald-800 px-3 py-1 rounded-full text-sm font-semibold">
                    Open
                  </span>
                )}
                {place.place_link && (
                  <a
                    href={place.place_link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-4 inline-block bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 px-4 rounded-full transition duration-300"
                  >
                    View Details
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* No Results Message */}
      {selectedPlace && !loading && nearbyPlaces.length === 0 && (
        <div className="text-center text-xl text-stone-600 my-12">
          No hiking spots found in this area. Try searching a different location.
        </div>
      )}

      {/* Footer */}
      <footer className="bg-stone-900 text-white py-8 px-4 mt-12">
        <div className="max-w-6xl mx-auto text-center">
          <p className="text-stone-400">
            © 2025 Trail Blazers Hiking Club. All trails lead to adventure.
          </p>
        </div>
      </footer>
    </div>
  );
}