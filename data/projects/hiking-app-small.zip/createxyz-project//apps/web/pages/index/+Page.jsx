import { useState, useEffect } from "react";

export default function HikingClubLanding() {
  const [heroImage, setHeroImage] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchHeroImage() {
      try {
        const response = await fetch("/api/pexels-random-image-generator", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            query: "majestic mountain wilderness sunrise hiking",
            targetWidth: 1920,
            targetHeight: 1080,
            random: true,
          }),
        });

        if (!response.ok) {
          throw new Error("Failed to fetch hero image");
        }

        const data = await response.json();
        setHeroImage(data);
      } catch (err) {
        console.error("Error fetching hero image:", err);
        setError("Failed to load hero image");
      }
    }

    fetchHeroImage();
  }, []);

  return (
    <div className="min-h-screen bg-stone-100">
      {/* Hero Section */}
      <div className="relative h-screen">
        {heroImage ? (
          <img
            src={heroImage.url}
            alt="Majestic mountain wilderness"
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full bg-stone-200" />
        )}
        <div className="absolute inset-0 bg-black bg-opacity-30" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white px-4">
          <h1
            className="text-5xl md:text-7xl font-bold text-center mb-6"
            style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.5)" }}
          >
            Trail Blazers Hiking Club
          </h1>
          <p
            className="text-xl md:text-2xl text-center mb-8 max-w-2xl"
            style={{ textShadow: "1px 1px 2px rgba(0,0,0,0.5)" }}
          >
            Where every trail leads to adventure and every summit tells a story
          </p>
          <button className="bg-amber-700 hover:bg-amber-800 text-white font-bold py-4 px-10 rounded-full text-lg transition duration-300 transform hover:scale-105 shadow-lg">
            Begin Your Journey
          </button>
        </div>
      </div>

      {/* Nature Quote Section */}
      <div className="bg-emerald-900 text-white py-8 px-4">
        <div className="max-w-4xl mx-auto text-center italic">
          <p className="text-xl md:text-2xl">
            "In every walk with nature, one receives far more than he seeks."
          </p>
          <p className="text-lg mt-2">- John Muir</p>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-20 px-4 max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          <div className="bg-white rounded-lg p-8 shadow-lg transform hover:scale-105 transition duration-300">
            <div className="bg-emerald-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <svg
                className="w-10 h-10 text-emerald-700"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064"
                />
              </svg>
            </div>
            <h3 className="text-2xl font-semibold mb-4 text-emerald-900 text-center">
              Guided Adventures
            </h3>
            <p className="text-stone-600 text-center">
              Expert-led hikes every weekend to hidden waterfalls, alpine
              meadows, and breathtaking peaks
            </p>
          </div>
          <div className="bg-white rounded-lg p-8 shadow-lg transform hover:scale-105 transition duration-300">
            <div className="bg-emerald-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <svg
                className="w-10 h-10 text-emerald-700"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                />
              </svg>
            </div>
            <h3 className="text-2xl font-semibold mb-4 text-emerald-900 text-center">
              Trail Community
            </h3>
            <p className="text-stone-600 text-center">
              Connect with fellow outdoor enthusiasts who share your passion for
              wilderness exploration
            </p>
          </div>
          <div className="bg-white rounded-lg p-8 shadow-lg transform hover:scale-105 transition duration-300">
            <div className="bg-emerald-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <svg
                className="w-10 h-10 text-emerald-700"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"
                />
              </svg>
            </div>
            <h3 className="text-2xl font-semibold mb-4 text-emerald-900 text-center">
              Nature For All
            </h3>
            <p className="text-stone-600 text-center">
              From gentle nature walks to challenging summit attempts, find your
              perfect outdoor experience
            </p>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="relative py-20 px-4">
        <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/1647972/pexels-photo-1647972.jpeg')] bg-cover bg-center"></div>
        <div className="absolute inset-0 bg-black bg-opacity-60"></div>
        <div className="relative max-w-4xl mx-auto text-center text-white">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Answer the Call of the Wild
          </h2>
          <p className="text-xl mb-10 max-w-2xl mx-auto">
            Join our community of outdoor enthusiasts and discover the
            transformative power of nature together.
          </p>
          <button className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-4 px-10 rounded-full text-lg transition duration-300 transform hover:scale-105 shadow-xl">
            Become a Trail Blazer
          </button>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-stone-900 text-white py-12 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center md:text-left">
              <h2 className="text-2xl font-bold text-amber-500">
                Trail Blazers
              </h2>
              <p className="text-stone-400 mt-2">Exploring nature since 2025</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4 text-amber-500">
                Explore
              </h3>
              <ul className="space-y-2">
                <li>
                  <a
                    href="#"
                    className="text-stone-300 hover:text-white transition duration-300"
                  >
                    Upcoming Hikes
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-stone-300 hover:text-white transition duration-300"
                  >
                    Trail Maps
                  </a>
                </li>
                <li>
                  <a
                    href="/hiking-history"
                    className="text-stone-300 hover:text-white transition duration-300"
                  >
                    Hiking History
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-stone-300 hover:text-white transition duration-300"
                  >
                    Photo Gallery
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4 text-amber-500">
                Community
              </h3>
              <ul className="space-y-2">
                <li>
                  <a
                    href="#"
                    className="text-stone-300 hover:text-white transition duration-300"
                  >
                    Join Us
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-stone-300 hover:text-white transition duration-300"
                  >
                    Events
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-stone-300 hover:text-white transition duration-300"
                  >
                    Blog
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4 text-amber-500">
                Contact
              </h3>
              <ul className="space-y-2">
                <li>
                  <a
                    href="#"
                    className="text-stone-300 hover:text-white transition duration-300"
                  >
                    About Us
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-stone-300 hover:text-white transition duration-300"
                  >
                    Get in Touch
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-stone-300 hover:text-white transition duration-300"
                  >
                    Safety Guide
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
