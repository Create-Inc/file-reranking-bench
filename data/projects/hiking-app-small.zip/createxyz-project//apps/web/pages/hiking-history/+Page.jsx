import { useState, useEffect } from 'react';

export default function HikingHistory() {
  const [heroImage, setHeroImage] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchHeroImage() {
      try {
        const response = await fetch('/api/pexels-random-image-generator', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            query: 'vintage mountaineering historic alps',
            targetWidth: 1920,
            targetHeight: 1080,
            random: true
          })
        });

        if (!response.ok) {
          throw new Error('Failed to fetch hero image');
        }

        const data = await response.json();
        setHeroImage(data);
      } catch (err) {
        console.error('Error fetching hero image:', err);
        setError('Failed to load hero image');
      }
    }

    fetchHeroImage();
  }, []);

  const timelineEvents = [
    {
      year: '10,000 BCE',
      title: 'Early Human Migration',
      description: 'First evidence of humans using mountain passes and trails for migration and trade across continents.',
      icon: (
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2"
          d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
        />
      )
    },
    {
      year: '1336',
      title: 'First Recreational Climb',
      description: 'Italian poet Petrarch climbed Mount Ventoux in France, marking one of the first documented recreational climbs in history.',
      icon: (
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2"
          d="M3 21v-4m0 0V5a2 2 0 012-2h6.5l1 1H21l-3 6 3 6h-8.5l-1-1H5a2 2 0 00-2 2zm9-13.5V9"
        />
      )
    },
    {
      year: '1786',
      title: 'Mont Blanc Ascent',
      description: 'First ascent of Mont Blanc by Jacques Balmat and Dr. Michel Paccard, marking the birth of modern mountaineering.',
      icon: (
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2"
          d="M13 10V3L4 14h7v7l9-11h-7z"
        />
      )
    },
    {
      year: '1857',
      title: 'Alpine Club Founded',
      description: 'The world\'s first mountaineering club, the Alpine Club, was founded in London.',
      icon: (
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2"
          d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
        />
      )
    },
    {
      year: '1876',
      title: 'Appalachian Mountain Club',
      description: 'America\'s oldest recreational hiking club was founded, promoting outdoor recreation and conservation.',
      icon: (
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2"
          d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064"
        />
      )
    },
    {
      year: '1921-1953',
      title: 'The Quest for Everest',
      description: 'Multiple expeditions attempted to climb Mount Everest, culminating in the successful ascent by Edmund Hillary and Tenzing Norgay.',
      icon: (
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2"
          d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"
        />
      )
    },
    {
      year: '1968',
      title: 'National Trails System Act',
      description: 'U.S. legislation established a network of protected trails, including the Appalachian and Pacific Crest Trails.',
      icon: (
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2"
          d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"
        />
      )
    }
  ];

  return (
    <div className="min-h-screen bg-stone-100">
      {/* Hero Section */}
      <div className="relative h-[50vh]">
        {heroImage ? (
          <img
            src={heroImage.url}
            alt="Historic mountaineering"
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full bg-stone-200" />
        )}
        <div className="absolute inset-0 bg-black bg-opacity-40" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white px-4">
          <h1 className="text-4xl md:text-6xl font-bold text-center mb-4" style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.5)' }}>
            The History of Hiking
          </h1>
          <p className="text-xl md:text-2xl text-center max-w-3xl" style={{ textShadow: '1px 1px 2px rgba(0,0,0,0.5)' }}>
            A journey through time: From ancient pathways to modern trails
          </p>
        </div>
      </div>

      {/* Introduction */}
      <div className="bg-emerald-900 text-white py-12 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-xl md:text-2xl italic mb-6">
            "The mountains are calling and I must go."
          </p>
          <p className="text-lg">- John Muir, 1873</p>
        </div>
      </div>

      {/* Timeline */}
      <div className="max-w-6xl mx-auto py-16 px-4">
        <div className="space-y-12">
          {timelineEvents.map((event, index) => (
            <div
              key={event.year}
              className={`flex flex-col md:flex-row items-center gap-8 ${
                index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
              }`}
            >
              <div className="w-full md:w-1/3 bg-white rounded-lg p-6 shadow-lg transform hover:scale-105 transition duration-300">
                <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-amber-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    {event.icon}
                  </svg>
                </div>
                <h3 className="text-2xl font-bold text-amber-700 text-center mb-2">{event.year}</h3>
                <h4 className="text-xl font-semibold text-emerald-900 text-center mb-4">{event.title}</h4>
              </div>
              <div className="hidden md:block w-12 h-2 md:w-2 md:h-32 bg-emerald-700 rounded-full transform md:translate-y-0"></div>
              <div className="w-full md:w-1/2 bg-white rounded-lg p-6 shadow-lg">
                <p className="text-stone-600 text-lg">{event.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-stone-800 text-white py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Continue the Legacy</h2>
          <p className="text-xl mb-8">
            Join us in writing the next chapter of hiking history. Every journey adds to the story.
          </p>
          <button className="bg-amber-700 hover:bg-amber-800 text-white font-bold py-4 px-10 rounded-full text-lg transition duration-300 transform hover:scale-105 shadow-lg">
            Start Your Adventure
          </button>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-stone-900 text-white py-8 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <p className="text-stone-400">
            © 2025 Trail Blazers Hiking Club. Preserving hiking history and creating new adventures.
          </p>
        </div>
      </footer>
    </div>
  );
}